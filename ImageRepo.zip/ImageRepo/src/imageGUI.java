import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Random;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;


public class imageGUI implements ActionListener{
	JFrame frame = new JFrame();

	JPanel mainPanel = new JPanel();
	JPanel menuPanel = new JPanel();
	JPanel displayPanel = new JPanel();

	JLabel imageLabel = new JLabel();
	JLabel statusLabel = new JLabel();
	ImageIcon newImage;
	int selectedImage;

	JButton randomButton = new JButton("Random Image");
	JButton addButton = new JButton("Add Image");
	JButton likeButton = new JButton("Like Image");
	JButton dislikeButton = new JButton("Dislike Image");
	
	boolean randomClick = false;
	//Constructor for the application (class)
	imageGUI()
	{
		//Splitting the main panel into two sub panels along the X axis
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));
		mainPanel.setLayout(new GridLayout(1,2, 1,0));
		menuPanel.setLayout(new GridLayout(5,1,0,1));
		//Adding a boxLayout component to the main window frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.setVisible(true);
		frame.setSize(600, 600);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));

		//Adding buttons and spacing
		menuPanel.add(randomButton);
		menuPanel.add(Box.createVerticalStrut(50));
		menuPanel.add(addButton);
		menuPanel.add(Box.createVerticalStrut(50));
		menuPanel.add(likeButton);
		menuPanel.add(Box.createVerticalStrut(50));
		menuPanel.add(dislikeButton);
		menuPanel.add(Box.createVerticalStrut(50));

		//Initializing the actionListener for each button being pressed
		randomButton.addActionListener(this);
		addButton.addActionListener(this);
		addButton.addActionListener(this);
		likeButton.addActionListener(this);
		dislikeButton.addActionListener(this);

		displayPanel.add(imageLabel);
		displayPanel.add(statusLabel);
		//Adding the 2 sub panels into the main panel
		mainPanel.add(menuPanel);
		mainPanel.add(displayPanel);

		
		//Adding the main panel onto the frame
		frame.add(mainPanel);
	}
	
	public void likedStatus(boolean status)
	{
		if(status == true)
			statusLabel.setText("Liked!");
		else
			statusLabel.setText("Disliked!");
	}
	
    // Methode to resize imageIcon with the same size of a Jlabel
   public ImageIcon resizeNewImage(String ImagePath)
   {
       ImageIcon MyImage = new ImageIcon(ImagePath);
       Image img = MyImage.getImage();
       Image newImg = img.getScaledInstance(400, 400, Image.SCALE_SMOOTH);
       ImageIcon image = new ImageIcon(newImg);
       return image;
   }
   
   public void searchForFile()
   {
		JFileChooser file = new JFileChooser();
		file.setCurrentDirectory(new File(System.getProperty("user.home")));
		FileNameExtensionFilter filter = new FileNameExtensionFilter("jpg","png");
       file.addChoosableFileFilter(filter);
       
       if(file.showOpenDialog(addButton) == JFileChooser.APPROVE_OPTION){
           File selectedFile = file.getSelectedFile();
           String path = selectedFile.getAbsolutePath();
           imageLabel.setIcon(resizeNewImage(path));
           
			frame.revalidate();
			frame.repaint();
       }
   }
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource() == randomButton)
		{
			randomClick = true;
			
			Random r = new Random();
			selectedImage = r.nextInt(5)+1;
			System.out.println(selectedImage);
			
			//Removing the components from last time
			displayPanel.remove(imageLabel);
			statusLabel.setText("");
			
			newImage = new ImageIcon(getClass().getResource("Image" + selectedImage + ".jpg"));
			imageLabel = new JLabel(newImage);
			displayPanel.add(imageLabel);
			
			
			
			frame.revalidate();
			frame.repaint();
		}
		
		if(e.getSource() == likeButton)
		{
			if(randomClick == true)
			{
				likedStatus(true);
			}
		}
		
		if(e.getSource() == dislikeButton)
		{
			if(randomClick == true)
			{
				likedStatus(false);
			}		
		}
		
		if(e.getSource() == addButton)
		{
			randomClick = true;
			searchForFile();

		}
	}
}
